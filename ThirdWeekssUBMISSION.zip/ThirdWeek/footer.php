<!-- By Meer Modi 09/22/2023 IT-202 005 Unit 3 Assignment mnm23-->
<footer>
    <h5>
        <p2>Meer Modi, 09/20/2023, AD-901-001, Week 3 Project, <a href ="Email to: mnm@njit.edu" class = "email">mnm@njit.edu</a></p2>
    </h5>
    <style>
        h5{
            background-color: navy;
            color: yellow;
        }
    </style>
</footer>
<!-- By Meer Modi 09/22/2023 IT-202 005 Unit 3 Assignment mnm23-->
<html>
    <head>
        <title>Android Development</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <?php include('header.php'); ?>
        <main>
            <h3>Course Details:</h3>
            <a href = "https://developer.android.com/kotlin?gclid=CjwKCAjwsKqoBhBPEiwALrrqiBRdc0D-9YQyQdfSt1aWEZ2ztV2pJdWO5gZn1QCb6qIi86vMay8ENxoCeFgQAvD_BwE&gclsrc=aw.ds" target="_blank"> Resource For Android Dev </a>
            <p class = "details">This course is about Android Development using Kotlin Programming language.<br> 
                This course uses Android Studio as an IDE. <br> This course concentrates more on Backend than UI</p>
            <ul>
                <li id = "first">Subject: AD</li>
                <li>Number: 901</li>
                <li>Credit: 4</li>
                <li>Prerequisites:
                    <ol>
                        <li>CS 480</li>
                        <li>MATH 333</li>
                    </ol>
                </li>
            </ul>
            
        </main>
        <?php include('footer.php'); ?>
    </body>
</html>
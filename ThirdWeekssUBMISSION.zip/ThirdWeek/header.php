<!-- By Meer Modi 09/22/2023 IT-202 005 Unit 3 Assignment mnm23-->
<header>
    <img src = "kotlin.png" alt ="Kotlin Logo" height="85"/> 
    <!-- alt is used when something goes wrong and image does not show -->
    <h1>Course Name: Android Development</h1>
    <style>
        h1{
            background-color: blue;
            color: greenyellow;
        }
    </style>
    <h2>Course Subject: AD</h2>
    <style>
        h2{
            background-color: purple;
            color: yellow;
        }
    </style>
</header>
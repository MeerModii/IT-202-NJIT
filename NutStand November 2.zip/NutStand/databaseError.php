<html>
    <head>
        <title>Guitar Shop</title>
    </head>
    <body>
        <main>
            <h1>DataBase Error</h1>
            <p>There was an error connecting to the database</p>
            <p>Error Message: <?php echo $error_message; ?></p>
        </main>
    </body>
</html>